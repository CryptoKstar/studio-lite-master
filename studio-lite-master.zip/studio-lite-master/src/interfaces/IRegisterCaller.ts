export interface IRegisterCaller {
    registerCaller(caller:any):void;
}
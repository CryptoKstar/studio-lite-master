export enum BlockTypeEnum {
    'COMPONENT',
    'RESOURCE',
    'SCENE'
}

import {StoreModel} from "../models/StoreModel";
export class LiveLogModel extends StoreModel {

    constructor(data) {
        super(data);
    }

}
